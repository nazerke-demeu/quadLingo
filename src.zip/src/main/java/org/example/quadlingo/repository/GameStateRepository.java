package org.example.quadlingo.repository;

import org.example.quadlingo.GameState;
import org.example.quadlingo.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameStateRepository extends JpaRepository<GameState, Long> {
    GameState findByUser(User user);
}