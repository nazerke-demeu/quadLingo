package org.example.quadlingo.controller;

import org.example.quadlingo.GameState;
import org.example.quadlingo.User;
import org.example.quadlingo.Word;
import org.example.quadlingo.service.GameService;
import org.example.quadlingo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/game")
public class GameController {

    @Autowired
    private GameService gameService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String showGame(Model model) {
        User user = userService.getCurrentUser();
        if (user == null || user.getRole().equals("ADMIN")) {
            return "redirect:/home";
        }
        GameState state = gameService.getGameState(user);
        boolean canPlay = gameService.canPlayGame(user);
        long remainingMinutes = gameService.getRemainingMinutes(user);
        long remainingSeconds = gameService.getRemainingSeconds(user);
        model.addAttribute("gameState", state);
        model.addAttribute("score", 0);
        model.addAttribute("canPlay", canPlay);
        model.addAttribute("remainingMinutes", remainingMinutes);
        model.addAttribute("remainingSeconds", remainingSeconds);
        return "mini_game";
    }

    @GetMapping("/start")
    public String startGame(@RequestParam String difficulty, Model model) {
        User user = userService.getCurrentUser();
        if (!gameService.canPlayGame(user)) {
            // Передаём необходимые переменные перед редиректом
            GameState state = gameService.getGameState(user);
            boolean canPlay = gameService.canPlayGame(user);
            long remainingMinutes = gameService.getRemainingMinutes(user);
            long remainingSeconds = gameService.getRemainingSeconds(user);
            model.addAttribute("gameState", state);
            model.addAttribute("score", 0);
            model.addAttribute("canPlay", canPlay);
            model.addAttribute("remainingMinutes", remainingMinutes);
            model.addAttribute("remainingSeconds", remainingSeconds);
            return "mini_game";
        }
        GameState state = gameService.getGameState(user);
        state.setCurrentDifficulty(difficulty.toUpperCase());
        gameService.resetGame(user);
        Word word = gameService.getRandomWord(difficulty);
        model.addAttribute("gameState", state);
        model.addAttribute("word", word);
        model.addAttribute("score", 0);
        model.addAttribute("questionsAnswered", state.getQuestionsAnswered());
        // Добавляем переменные canPlay, remainingMinutes, remainingSeconds
        model.addAttribute("canPlay", gameService.canPlayGame(user));
        model.addAttribute("remainingMinutes", gameService.getRemainingMinutes(user));
        model.addAttribute("remainingSeconds", gameService.getRemainingSeconds(user));
        return "mini_game";
    }

    @PostMapping("/answer")
    public String submitAnswer(@RequestParam Long wordId, @RequestParam String answer, @RequestParam int score, Model model) {
        User user = userService.getCurrentUser();
        GameState state = gameService.getGameState(user);
        boolean isCorrect = gameService.checkAnswer(user, wordId, answer, score);
        if (isCorrect) {
            score++;
        }
        if (gameService.isGameOver(state)) {
            model.addAttribute("gameOver", true);
            model.addAttribute("score", score);
            model.addAttribute("gameState", state);
            // Добавляем переменные canPlay, remainingMinutes, remainingSeconds
            model.addAttribute("canPlay", gameService.canPlayGame(user));
            model.addAttribute("remainingMinutes", gameService.getRemainingMinutes(user));
            model.addAttribute("remainingSeconds", gameService.getRemainingSeconds(user));
            return "mini_game";
        }
        Word nextWord = gameService.getRandomWord(state.getCurrentDifficulty());
        model.addAttribute("gameState", state);
        model.addAttribute("word", nextWord);
        model.addAttribute("score", score);
        model.addAttribute("questionsAnswered", state.getQuestionsAnswered());
        // Добавляем переменные canPlay, remainingMinutes, remainingSeconds
        model.addAttribute("canPlay", gameService.canPlayGame(user));
        model.addAttribute("remainingMinutes", gameService.getRemainingMinutes(user));
        model.addAttribute("remainingSeconds", gameService.getRemainingSeconds(user));
        return "mini_game";
    }
}