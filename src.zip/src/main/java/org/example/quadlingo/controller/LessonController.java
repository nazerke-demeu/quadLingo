package org.example.quadlingo.controller;

import org.example.quadlingo.Question;
import org.example.quadlingo.service.LessonService;
import org.example.quadlingo.service.QuestionService;
import org.example.quadlingo.service.QuizService;
import org.example.quadlingo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/learn")
public class LessonController {

    private static final int MAX_LIVES = 3;

    @Autowired
    private LessonService lessonService;

    @Autowired
    private UserService userService;

    @Autowired
    private QuizService quizService;

    @Autowired
    private QuestionService questionService;

    @GetMapping
    public String getLearnPage(Model model) {
        if (userService.getCurrentUser() == null) {
            return "redirect:/login";
        }
        model.addAttribute("lessons", lessonService.getAllLessons());
        model.addAttribute("isAdmin", userService.isAdmin());
        return "learn";
    }

    @PostMapping("/add")
    public String addLesson(@RequestParam String title, @RequestParam String description, @RequestParam String content, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            if (title == null || title.trim().isEmpty() || description == null || description.trim().isEmpty() || content == null || content.trim().isEmpty()) {
                model.addAttribute("error", "Title, description, and content cannot be empty");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (title.length() > 255) {
                model.addAttribute("error", "Title must be 255 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (description.length() > 10000) {
                model.addAttribute("error", "Description must be 10,000 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (content.length() > 10000) {
                model.addAttribute("error", "Content must be 10,000 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            lessonService.addLesson(title, description, content);
            return "redirect:/learn";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to add lesson: " + e.getMessage());
            model.addAttribute("lessons", lessonService.getAllLessons());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "learn";
        }
    }

    @GetMapping("/edit")
    public String showEditLessonForm(@RequestParam Integer id, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            var lessonOptional = lessonService.getLessonById(id);
            if (lessonOptional.isPresent()) {
                model.addAttribute("editLesson", lessonOptional.get());
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            } else {
                model.addAttribute("error", "Lesson not found");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to load lesson: " + e.getMessage());
            model.addAttribute("lessons", lessonService.getAllLessons());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "learn";
        }
    }

    @PostMapping("/edit")
    public String editLesson(@RequestParam Integer id, @RequestParam String title, @RequestParam String description, @RequestParam String content, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            if (title == null || title.trim().isEmpty() || description == null || description.trim().isEmpty() || content == null || content.trim().isEmpty()) {
                model.addAttribute("error", "Title, description, and content cannot be empty");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (title.length() > 255) {
                model.addAttribute("error", "Title must be 255 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (description.length() > 10000) {
                model.addAttribute("error", "Description must be 10,000 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (content.length() > 10000) {
                model.addAttribute("error", "Content must be 10,000 characters or less");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            lessonService.updateLesson(id, title, description, content);
            return "redirect:/learn";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to edit lesson: " + e.getMessage());
            model.addAttribute("lessons", lessonService.getAllLessons());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "learn";
        }
    }

    @PostMapping("/delete")
    public String deleteLesson(@RequestParam Integer id) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            lessonService.deleteLesson(id);
        } catch (Exception e) {
            // Логирование ошибки можно добавить здесь
        }
        return "redirect:/learn";
    }

    @PostMapping("/quiz/add")
    public String addQuiz(@RequestParam Integer lessonId, @RequestParam String quizTitle,
                          @RequestParam Map<String, String> allParams, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            var lessonOptional = lessonService.getLessonById(lessonId);
            if (lessonOptional.isEmpty()) {
                model.addAttribute("error", "Lesson not found");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
            if (quizTitle == null || quizTitle.trim().isEmpty()) {
                model.addAttribute("error", "Quiz title cannot be empty");
                model.addAttribute("lesson", lessonOptional.get());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "quiz_management";
            }
            quizService.addQuiz(quizTitle, lessonOptional.get());
            var quizOptional = quizService.getQuizById(quizService.getQuizById(lessonOptional.get().getQuizzes().get(lessonOptional.get().getQuizzes().size() - 1).getId()).get().getId());
            if (quizOptional.isPresent()) {
                List<Map<String, String>> questions = new ArrayList<>();
                int questionIndex = 1;
                while (allParams.containsKey("questions[" + questionIndex + "].text")) {
                    Map<String, String> question = new HashMap<>();
                    question.put("text", allParams.get("questions[" + questionIndex + "].text"));
                    question.put("option1", allParams.get("questions[" + questionIndex + "].option1"));
                    question.put("option2", allParams.get("questions[" + questionIndex + "].option2"));
                    question.put("option3", allParams.get("questions[" + questionIndex + "].option3"));
                    question.put("option4", allParams.get("questions[" + questionIndex + "].option4"));
                    question.put("correct", allParams.get("questions[" + questionIndex + "].correct"));
                    questions.add(question);
                    questionIndex++;
                }
                for (Map<String, String> question : questions) {
                    String text = question.get("text");
                    String option1 = question.get("option1");
                    String option2 = question.get("option2");
                    String option3 = question.get("option3");
                    String option4 = question.get("option4");
                    Integer correct = Integer.parseInt(question.get("correct"));
                    questionService.addQuestion(text, option1, option2, option3, option4, correct, quizOptional.get());
                }
            }
            return "redirect:/learn/quiz/manage?lessonId=" + lessonId;
        } catch (Exception e) {
            model.addAttribute("error", "Failed to add quiz: " + e.getMessage());
            model.addAttribute("lesson", lessonService.getLessonById(lessonId).get());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "quiz_management";
        }
    }

    @GetMapping("/quiz/edit")
    public String showEditQuizForm(@RequestParam Integer id, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            var quizOptional = quizService.getQuizById(id);
            if (quizOptional.isPresent()) {
                model.addAttribute("editQuiz", quizOptional.get());
                model.addAttribute("lesson", quizOptional.get().getLesson());
                model.addAttribute("questions", questionService.getQuestionsByQuiz(quizOptional.get()));
                model.addAttribute("isAdmin", userService.isAdmin());
                return "quiz_management";
            } else {
                model.addAttribute("error", "Quiz not found");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to load quiz: " + e.getMessage());
            model.addAttribute("lessons", lessonService.getAllLessons());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "learn";
        }
    }

    @PostMapping("/quiz/edit")
    public String editQuiz(@RequestParam Integer id, @RequestParam String quizTitle,
                           @RequestParam Map<String, String> allParams, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            var quizOptional = quizService.getQuizById(id);
            if (quizOptional.isEmpty()) {
                model.addAttribute("error", "Quiz not found");
                model.addAttribute("editQuiz", quizService.getQuizById(id).orElse(null));
                model.addAttribute("lesson", quizService.getQuizById(id).get().getLesson());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "quiz_management";
            }
            if (quizTitle == null || quizTitle.trim().isEmpty()) {
                model.addAttribute("error", "Quiz title cannot be empty");
                model.addAttribute("editQuiz", quizService.getQuizById(id).orElse(null));
                model.addAttribute("lesson", quizService.getQuizById(id).get().getLesson());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "quiz_management";
            }

            // Update quiz title
            quizService.updateQuiz(id, quizTitle);

            // Process questions
            List<Map<String, String>> questions = new ArrayList<>();
            int questionIndex = 1;
            while (allParams.containsKey("questions[" + questionIndex + "].text")) {
                Map<String, String> question = new HashMap<>();
                question.put("id", allParams.get("questions[" + questionIndex + "].id"));
                question.put("text", allParams.get("questions[" + questionIndex + "].text"));
                question.put("option1", allParams.get("questions[" + questionIndex + "].option1"));
                question.put("option2", allParams.get("questions[" + questionIndex + "].option2"));
                question.put("option3", allParams.get("questions[" + questionIndex + "].option3"));
                question.put("option4", allParams.get("questions[" + questionIndex + "].option4"));
                question.put("correct", allParams.get("questions[" + questionIndex + "].correct"));
                questions.add(question);
                questionIndex++;
            }

            // Get existing questions
            var existingQuestions = questionService.getQuestionsByQuiz(quizOptional.get());
            List<Integer> submittedQuestionIds = new ArrayList<>();
            for (Map<String, String> question : questions) {
                String text = question.get("text");
                String option1 = question.get("option1");
                String option2 = question.get("option2");
                String option3 = question.get("option3");
                String option4 = question.get("option4");
                Integer correct = Integer.parseInt(question.get("correct"));
                String idStr = question.get("id");

                if (idStr != null && !idStr.isEmpty()) {
                    // Update existing question
                    Integer questionId = Integer.parseInt(idStr);
                    submittedQuestionIds.add(questionId);
                    questionService.updateQuestion(questionId, text, option1, option2, option3, option4, correct);
                } else {
                    // Add new question
                    questionService.addQuestion(text, option1, option2, option3, option4, correct, quizOptional.get());
                }
            }

            // Delete questions that were removed
            for (var existingQuestion : existingQuestions) {
                if (!submittedQuestionIds.contains(existingQuestion.getId())) {
                    questionService.deleteQuestion(existingQuestion.getId());
                }
            }

            return "redirect:/learn/quiz/manage?lessonId=" + quizOptional.get().getLesson().getId();
        } catch (Exception e) {
            model.addAttribute("error", "Failed to edit quiz: " + e.getMessage());
            model.addAttribute("editQuiz", quizService.getQuizById(id).orElse(null));
            model.addAttribute("lesson", quizService.getQuizById(id).get().getLesson());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "quiz_management";
        }
    }

    @PostMapping("/quiz/delete")
    public String deleteQuiz(@RequestParam Integer id) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            Integer lessonId = quizService.getQuizById(id).get().getLesson().getId();
            quizService.deleteQuiz(id);
            return "redirect:/learn/quiz/manage?lessonId=" + lessonId;
        } catch (Exception e) {
            return "redirect:/learn";
        }
    }

    @GetMapping("/quiz/take")
    public String takeQuiz(@RequestParam Integer id, HttpSession session, Model model) {
        if (userService.getCurrentUser() == null) {
            return "redirect:/login";
        }
        var quizOptional = quizService.getQuizById(id);
        if (quizOptional.isPresent()) {
            session.setAttribute("quizAnswers", new HashMap<Integer, Integer>());
            session.setAttribute("lives", MAX_LIVES); // Инициализация 3 жизней
            model.addAttribute("quiz", quizOptional.get());
            model.addAttribute("questions", questionService.getQuestionsByQuiz(quizOptional.get()));
            model.addAttribute("currentQuestionIndex", 0);
            model.addAttribute("lives", MAX_LIVES);
            return "quiz";
        }
        model.addAttribute("error", "Quiz not found");
        return "learn";
    }

    @PostMapping("/quiz/next")
    public String nextQuestion(@RequestParam Integer quizId, @RequestParam Integer currentQuestionIndex,
                               @RequestParam Map<String, String> allParams, HttpSession session, Model model) {
        var quizOptional = quizService.getQuizById(quizId);
        if (quizOptional.isEmpty()) {
            model.addAttribute("error", "Quiz not found");
            return "learn";
        }

        var questions = questionService.getQuestionsByQuiz(quizOptional.get());
        if (questions.isEmpty()) {
            model.addAttribute("error", "No questions available");
            return "learn";
        }

        // Получение данных из сессии
        @SuppressWarnings("unchecked")
        Map<Integer, Integer> quizAnswers = (Map<Integer, Integer>) session.getAttribute("quizAnswers");
        Integer lives = (Integer) session.getAttribute("lives");
        if (quizAnswers == null) {
            quizAnswers = new HashMap<>();
        }
        if (lives == null) {
            lives = MAX_LIVES;
        }

        // Обработка ответа
        var question = questions.get(currentQuestionIndex);
        String answerKey = "answer_" + question.getId();
        if (allParams.containsKey(answerKey)) {
            try {
                int answerValue = Integer.parseInt(allParams.get(answerKey));
                quizAnswers.put(question.getId(), answerValue);
                // Проверка правильности ответа
                if (answerValue != question.getCorrectOption()) {
                    lives--; // Уменьшить жизнь при неправильном ответе
                    session.setAttribute("lives", lives);
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid answer format: " + allParams.get(answerKey));
            }
        }
        session.setAttribute("quizAnswers", quizAnswers);

        // Проверка на окончание жизней
        if (lives <= 0) {
            int score = calculateScore(quizAnswers, questions);
            session.removeAttribute("quizAnswers");
            session.removeAttribute("lives");
            model.addAttribute("quiz", quizOptional.get());
            model.addAttribute("score", score);
            model.addAttribute("total", questions.size());
            model.addAttribute("lives", 0);
            return "quiz";
        }

        // Переход к следующему вопросу или результат
        if (currentQuestionIndex + 1 < questions.size()) {
            model.addAttribute("quiz", quizOptional.get());
            model.addAttribute("questions", questions);
            model.addAttribute("currentQuestionIndex", currentQuestionIndex + 1);
            model.addAttribute("lives", lives);
            return "quiz";
        } else {
            int score = calculateScore(quizAnswers, questions);
            session.removeAttribute("quizAnswers");
            session.removeAttribute("lives");
            model.addAttribute("quiz", quizOptional.get());
            model.addAttribute("score", score);
            model.addAttribute("total", questions.size());
            model.addAttribute("lives", lives);
            return "quiz";
        }
    }

    @GetMapping("/quiz/manage")
    public String manageQuizzes(@RequestParam Integer lessonId, Model model) {
        if (!userService.isAdmin()) {
            return "redirect:/learn";
        }
        try {
            var lessonOptional = lessonService.getLessonById(lessonId);
            if (lessonOptional.isPresent()) {
                model.addAttribute("lesson", lessonOptional.get());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "quiz_management";
            } else {
                model.addAttribute("error", "Lesson not found");
                model.addAttribute("lessons", lessonService.getAllLessons());
                model.addAttribute("isAdmin", userService.isAdmin());
                return "learn";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to load lesson: " + e.getMessage());
            model.addAttribute("lessons", lessonService.getAllLessons());
            model.addAttribute("isAdmin", userService.isAdmin());
            return "learn";
        }
    }

    private int calculateScore(Map<Integer, Integer> quizAnswers, List<Question> questions) {
        int score = 0;
        for (var question : questions) {
            Integer userAnswer = quizAnswers.get(question.getId());
            if (userAnswer != null && userAnswer == question.getCorrectOption()) {
                score++;
            }
        }
        return score;
    }
}